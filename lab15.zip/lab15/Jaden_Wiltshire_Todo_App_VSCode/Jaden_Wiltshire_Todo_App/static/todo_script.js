// Session 7 To-Do List — Jaden Wiltshire
const form = document.querySelector('#taskForm');
const input = document.querySelector('#taskInput');
const list = document.querySelector('#taskList');
const statusMessage = document.querySelector('#statusMessage');
const emptyState = document.querySelector('#emptyState');
const taskCount = document.querySelector('#taskCount');

async function apiRequest(url, options) {
  const response = await fetch(url, options);
  const result = await response.json();
  if (!response.ok) throw new Error(result.error || 'Request failed.');
  return result;
}

function showMessage(message, isError = false) {
  statusMessage.textContent = message;
  statusMessage.classList.toggle('error', isError);
}

function createTaskElement(id, taskText) {
  const li = document.createElement('li');
  li.className = 'task_item';
  li.dataset.taskId = id;
  const text = document.createElement('span');
  text.className = 'task_text';
  text.textContent = taskText;
  const button = document.createElement('button');
  button.className = 'btndeletetask';
  button.type = 'button';
  button.textContent = '✕';
  button.setAttribute('aria-label', `Delete task: ${taskText}`);
  button.addEventListener('click', () => deleteTask(id));
  li.append(text, button);
  return li;
}

async function loadTasks() {
  try {
    const tasks = await apiRequest('/get_tasks');
    list.replaceChildren(...tasks.map(task => createTaskElement(task.id, task.task)));
    taskCount.textContent = `${tasks.length} ${tasks.length === 1 ? 'task' : 'tasks'}`;
    emptyState.hidden = tasks.length !== 0;
    showMessage('');
  } catch (error) {
    showMessage(error.message, true);
  }
}

async function addTask() {
  const task = input.value.trim();
  if (!task) { showMessage('Please enter a task.', true); return; }
  const button = form.querySelector('button');
  button.disabled = true;
  try {
    await apiRequest('/add_task', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ task })
    });
    input.value = '';
    await loadTasks();
    input.focus();
  } catch (error) {
    showMessage(error.message, true);
  } finally {
    button.disabled = false;
  }
}

async function deleteTask(id) {
  try {
    await apiRequest('/delete_task', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ id })
    });
    await loadTasks();
  } catch (error) {
    showMessage(error.message, true);
  }
}

form.addEventListener('submit', event => { event.preventDefault(); addTask(); });
document.addEventListener('DOMContentLoaded', loadTasks);
