-- Session 7 MySQL setup — Jaden Wiltshire
CREATE DATABASE IF NOT EXISTS todo_db;
CREATE USER IF NOT EXISTS 'flaskuser'@'localhost' IDENTIFIED BY 'password123';
GRANT ALL PRIVILEGES ON todo_db.* TO 'flaskuser'@'localhost';
FLUSH PRIVILEGES;
USE todo_db;
CREATE TABLE IF NOT EXISTS tasks (
    id INT AUTO_INCREMENT PRIMARY KEY,
    task VARCHAR(255) NOT NULL
);
INSERT INTO tasks (task)
SELECT 'Sample Task' WHERE NOT EXISTS (SELECT 1 FROM tasks);
