# Session 7: To-Do List Web App
**Student:** Jaden Wiltshire

A Flask + JavaScript + MySQL to-do app built from the provided lab files. Routes: `GET /`, `GET /get_tasks`, `POST /add_task`, `POST /delete_task`. Tasks persist in MySQL; JavaScript `fetch()` updates the list without refreshing the page.

## Run locally in Visual Studio Code (Windows)

### 1. Install prerequisites
- Install **Python 3.10+** from python.org and check **Add Python to PATH** during installation.
- Install **MySQL Server 8.x** using MySQL Installer and remember the MySQL root password. Ensure the MySQL service is running.
- Install **Visual Studio Code** and the **Python** extension from Microsoft.

### 2. Open the folder
Extract the ZIP, then in VS Code choose **File > Open Folder** and select `Jaden_Wiltshire_Todo_App`. Open **Terminal > New Terminal** (PowerShell).

### 3. Create the MySQL database
In the VS Code terminal run:

```powershell
mysql -u root -p < setup.sql
```

**Important:** PowerShell does not support `<` input redirection. Run this command in a **Command Prompt (cmd)** terminal instead (terminal dropdown > Select Default Profile > Command Prompt), or in PowerShell use:

```powershell
Get-Content setup.sql | mysql -u root -p
```

Enter the MySQL root password when prompted. If `mysql` is not recognized, add MySQL Server's `bin` folder (for example `C:\Program Files\MySQL\MySQL Server 8.0\bin`) to PATH, reopen VS Code, or use the full path to `mysql.exe`.

The SQL script creates database `todo_db`, user `flaskuser` with lab password `password123`, and table `tasks`.

### 4. Install Python packages
In a PowerShell terminal:

```powershell
py -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
```

Choose the `.venv` interpreter in VS Code with **Ctrl+Shift+P > Python: Select Interpreter**. No activation is required when using the commands shown here.

### 5. Start the app

```powershell
.\.venv\Scripts\python.exe app.py
```

Open **http://127.0.0.1:5000/** in your browser. Stop the server with Ctrl+C. You can also press **F5** using the included `.vscode/launch.json` configuration after selecting the `.venv` interpreter.

## macOS / Linux in VS Code
Install MySQL Server, start the service, and run `mysql -u root -p < setup.sql` in a shell. Then:

```bash
python3 -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
.venv/bin/python app.py
```

## Verify the lab
1. Confirm the page heading says **Jaden Wiltshire**.
2. Add a task; it should appear without reloading.
3. Refresh the page; the task should still be present.
4. Delete the task; it should disappear without reloading.
5. Visit **http://127.0.0.1:5000/get_tasks** to see JSON.
6. Optionally inspect the table in MySQL: `SELECT * FROM todo_db.tasks;`

## Troubleshooting
- **Can't connect to MySQL:** Start the local MySQL service and verify `flaskuser`, password, and database exist by running `setup.sql`.
- **`mysql` not recognized:** Add MySQL's `bin` directory to PATH and restart the terminal.
- **`ModuleNotFoundError`:** Install requirements using the `.venv` Python command above.
- **Port 5000 in use:** Stop the other program or set `PORT` in the terminal (`$env:PORT='5001'` in PowerShell) before starting Flask.

Environment overrides: `MYSQL_HOST`, `MYSQL_USER`, `MYSQL_PASSWORD`, `MYSQL_DATABASE`, `PORT`, and `FLASK_DEBUG`. The default password is only for this local classroom lab; change it before any public deployment. Live MySQL integration testing must be done on your computer with MySQL running.
