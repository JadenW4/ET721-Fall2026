"""Session 7 To-Do List web application — Jaden Wiltshire."""
import os
from flask import Flask, jsonify, render_template, request
import mysql.connector

app = Flask(__name__)

def get_db_connection():
    return mysql.connector.connect(
        host=os.getenv('MYSQL_HOST', '127.0.0.1'),
        user=os.getenv('MYSQL_USER', 'flaskuser'),
        password=os.getenv('MYSQL_PASSWORD', 'password123'),
        database=os.getenv('MYSQL_DATABASE', 'todo_db'),
    )

@app.get('/')
def index():
    return render_template('index.html')

@app.get('/get_tasks')
def get_tasks():
    try:
        with get_db_connection() as db:
            with db.cursor(dictionary=True) as cursor:
                cursor.execute('SELECT id, task FROM tasks ORDER BY id ASC')
                tasks = cursor.fetchall()
        return jsonify(tasks)
    except mysql.connector.Error:
        app.logger.exception('Unable to retrieve tasks')
        return jsonify({'error': 'Unable to load tasks. Check the MySQL connection.'}), 500

@app.post('/add_task')
def add_task():
    data = request.get_json(silent=True)
    task = data.get('task', '') if isinstance(data, dict) else ''
    if not isinstance(task, str) or not task.strip():
        return jsonify({'error': 'Please enter a task.'}), 400
    task = task.strip()
    if len(task) > 255:
        return jsonify({'error': 'Task must be 255 characters or fewer.'}), 400
    try:
        with get_db_connection() as db:
            with db.cursor() as cursor:
                cursor.execute('INSERT INTO tasks (task) VALUES (%s)', (task,))
                task_id = cursor.lastrowid
                db.commit()
        return jsonify({'status': 'success', 'id': task_id, 'task': task}), 201
    except mysql.connector.Error:
        app.logger.exception('Unable to add task')
        return jsonify({'error': 'Unable to save task.'}), 500

@app.post('/delete_task')
def delete_task():
    data = request.get_json(silent=True)
    task_id = data.get('id') if isinstance(data, dict) else None
    if isinstance(task_id, bool) or not isinstance(task_id, int) or task_id <= 0:
        return jsonify({'error': 'A valid task ID is required.'}), 400
    try:
        with get_db_connection() as db:
            with db.cursor() as cursor:
                cursor.execute('DELETE FROM tasks WHERE id = %s', (task_id,))
                deleted = cursor.rowcount
                db.commit()
        if not deleted:
            return jsonify({'error': 'Task not found.'}), 404
        return jsonify({'status': 'deleted'})
    except mysql.connector.Error:
        app.logger.exception('Unable to delete task')
        return jsonify({'error': 'Unable to delete task.'}), 500

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=int(os.getenv('PORT', '5000')), debug=os.getenv('FLASK_DEBUG') == '1')
