Jaden Wiltshire
Professor Wu
ET721
11/15/2026

# **Report: The Benefits of Comprehensive Testing in Software Development**

## **Before and After: Results Summary**

**What was the initial test coverage?**

The initial test coverage wasn't recorded, but the starter project had several incomplete tests and parts of the application that weren't being tested.

**What is the final test coverage you were able to achieve?**

My goal was to achieve at least 80% code coverage by completing the missing tests and adding new ones. My final coverage was [insert actual percentage].

**How many tests did you end up having?**

The updated project includes 28 test cases, including tests for different search conditions and API features.

## **Untested Code: Effects**

**Were you able to understand all features and different use cases of the code without the tests?**

Not completely. I was able to understand some parts of the code by reading through it, but it was harder to figure out how certain functions worked without tests showing the expected results.

**What did you think of having to test the API manually?**

Testing the API manually was helpful at first because I could see how the requests worked. However, it became repetitive and time-consuming because I had to keep entering commands and checking the results myself.

**What was the result of having few tests on your understanding of the API?**

Having fewer tests made it harder to understand how the API handled different situations, especially errors and invalid inputs. Once I added more tests, I had a better understanding of what each function was supposed to do.

## **Adding Tests**

**How did you go about adding more tests to the code?**

I started by reviewing the existing tests and looking for functions that weren't being tested. Then I added tests for calculating fruit quantities, searching for fruits, handling invalid inputs, and using different API requests. I also tested what happened when the inventory was empty.

**What is the difference between a unit test and an API test? Do they bring different values?**

A unit test checks individual functions to make sure they work correctly. An API test checks how the application responds to requests like GET, POST, PUT, and DELETE. Both are important because unit tests help catch problems in specific functions, while API tests make sure the application works properly when different parts interact.

## **Automation**

**What were the benefits of automating test coverage?**

Automating test coverage saves time because tests can run automatically whenever changes are made to the code. Using GitHub Actions also helps catch errors early instead of finding them after the application has been updated. It makes the development process easier and more reliable.

## **New Features**

**What was your experience like having to add new features when you tested baseline code?**

Adding a new feature was easier because I already had tests checking the existing functions. When I added the fruit metrics endpoint, I could use the tests to check whether the new feature worked without affecting the rest of the application.

**Did it give you any feeling of security when trying out new features?**

Yes, having tests made me feel more confident when making changes. I knew that if something stopped working, the tests could help me identify the problem instead of having to search through the entire application manually.

## **Future**

**What do you hope to takeaway from the experience having to write tests?**

The biggest thing I learned from this project is that testing is an important part of writing good code. I still have alot to learn and i feel i'll be able to learn alot by doing projects like these more often.