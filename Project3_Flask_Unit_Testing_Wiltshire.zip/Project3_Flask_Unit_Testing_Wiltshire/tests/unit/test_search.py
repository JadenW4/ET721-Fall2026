import pytest
from app import create_app
from app.models import Fruit, db

@pytest.fixture
def seeded_app():
    app = create_app({"TESTING": True, "SQLALCHEMY_DATABASE_URI": "sqlite:///:memory:"})
    with app.app_context():
        db.session.add_all([
            Fruit(name="Apple", quantity=10, variety="Gala", season="Winter"),
            Fruit(name="Banana", quantity=20, variety="Cavendish", season="All"),
            Fruit(name="Apple", quantity=15, variety="Fuji", season="Winter"),
        ])
        db.session.commit()
        yield app
        db.session.remove()
        db.drop_all()

@pytest.mark.parametrize("filters,expected", [
    ({"name": "app"}, 2),
    ({"variety": "gala"}, 1),
    ({"season": "winter"}, 2),
    ({"min_quantity": 15}, 2),
    ({"max_quantity": 10}, 1),
    ({"name": "Apple", "min_quantity": 12}, 1),
    ({"name": "Pear"}, 0),
    ({}, 3),
])
def test_search_filters(seeded_app, filters, expected):
    with seeded_app.app_context():
        assert len(Fruit.search(**filters)) == expected
