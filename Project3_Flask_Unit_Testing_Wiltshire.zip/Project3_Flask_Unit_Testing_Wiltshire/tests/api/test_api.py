import json
import pytest
from app import create_app
from app.models import db, Fruit

@pytest.fixture
def app():
    app = create_app({"TESTING": True, "SQLALCHEMY_DATABASE_URI": "sqlite:///:memory:"})
    with app.app_context():
        db.create_all()
        # Put some initial data into the database
        fruits = [
            Fruit(name="Apple", quantity=10, variety="Gala", season="Winter"),
            Fruit(name="Banana", quantity=20, variety="Cavendish", season="All"),
        ]
        db.session.bulk_save_objects(fruits)
        db.session.commit()
    yield app

@pytest.fixture
def client(app):
    return app.test_client()

def test_getAllFruits_whenDatabaseHasFruits_returnsFruitsList(client):
    """
    Test fetching all fruits from the database
    Validates that the GET request to '/api/fruits' returns a 200 status code,
    the correct number of fruits, and specific data of the fruits
    """
    response = client.get('/api/fruits')
    data = json.loads(response.data)
    assert response.status_code == 200
    assert len(data) == 2  # Adjust based on your initial data
    assert data[0]['name'] == 'Apple'

def test_addFruit_withValidData_returnsSuccessMessageAndFruitId(client):
    """
    Test adding a new fruit to the database
    Validates that the POST request to '/api/fruits' adds the fruit correctly,
    and returns a 201 status code along with a success message and the fruit's ID
    """
    new_fruit = {"name": "Orange", "quantity": 5, "variety": "Navel", "season": "Winter"}
    response = client.post('/api/fruits', json=new_fruit)
    data = json.loads(response.data)
    assert response.status_code == 201
    assert data['message'] == 'Fruit added successfully'
    assert 'id' in data


def test_home(client):
    response = client.get('/')
    assert response.status_code == 200
    assert 'message' in response.get_json()

def test_update_existing_fruit(client):
    response = client.put('/api/fruits/1', json={'quantity': 25})
    assert response.status_code == 200
    fruits = client.get('/api/fruits').get_json()
    assert fruits[0]['quantity'] == 25
    assert fruits[0]['name'] == 'Apple'

def test_update_missing_fruit(client):
    response = client.put('/api/fruits/999', json={'quantity': 3})
    assert response.status_code == 404

def test_delete_existing_fruit(client):
    assert client.delete('/api/fruits/1').status_code == 200
    assert len(client.get('/api/fruits').get_json()) == 1

def test_delete_missing_fruit(client):
    assert client.delete('/api/fruits/999').status_code == 404

def test_search_endpoint(client):
    response = client.get('/api/fruits/search?name=apple&min_quantity=10&max_quantity=10&variety=Gala&season=Winter')
    assert response.status_code == 200
    assert [fruit['name'] for fruit in response.get_json()] == ['Apple']

def test_search_no_results(client):
    response = client.get('/api/fruits/search?name=Kiwi')
    assert response.status_code == 200
    assert response.get_json()['message'] == 'No fruits found matching the search criteria'

def test_metrics_endpoint(client):
    response = client.get('/api/fruits/metrics')
    assert response.status_code == 200
    assert response.get_json() == {'total_fruits': 2, 'average_quantity': 15.0, 'most_common_fruit': 'Apple'}

def test_metrics_empty_inventory(client):
    client.delete('/api/fruits/1')
    client.delete('/api/fruits/2')
    assert client.get('/api/fruits/metrics').get_json() == {'total_fruits': 0, 'average_quantity': 0, 'most_common_fruit': None}
